import java.util.Random;
import java.util.Scanner;

public class Ramdon {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random randomizacao = new Random();
        
        System.out.print("Digite seu nome completo: ");
        String nome = scanner.nextLine();

        int numeroSorte = randomizacao.nextInt(100);
        int tentativas = 0;
        boolean acertou = false;

        System.out.println("Bem-vindo, " + nome + "! Tente adivinhar o número da sorte entre 0 e 99.");

        while (!acertou) {
            System.out.print("Qual é o seu palpite? ");
            int palpite = scanner.nextInt();
            tentativas++;
 
            if (palpite == numeroSorte) {
                acertou = true;
                System.out.println("Parabéns, " + nome + "! Você acertou o número da sorte em " + tentativas + " tentativas!");
            } else if (palpite < numeroSorte) {
                System.out.println("O número da sorte é maior que " + palpite + ". Tente novamente.");
            } else {
                System.out.println("O número da sorte é menor que " + palpite + ". Tente novamente.");
            }
        }

        scanner.close();
    }
}